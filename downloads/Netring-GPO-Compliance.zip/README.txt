Netring GPO Compliance
Netring Tech Services, LLC.

What is in this package
  GPOCompliance.exe        The analyzer. Runs on Windows 10/11 or Server 2016+, no install, no admin rights.
  Collect-GpoData.ps1    Collector. Reads Active Directory and backs up the GPOs into a folder the analyzer opens.
  SHA256.txt             Hashes of the two files above. Both are signed by Netring Tech Services, LLC.

1. Collect
  On a domain-joined machine with the RSAT ActiveDirectory and GroupPolicy modules, signed in as a domain
  account that can read GPOs, open Windows PowerShell in the folder that holds the script and run:

      .\Collect-GpoData.ps1

  It only reads from Active Directory. It writes a GpoExport folder next to itself, one subfolder per domain in
  the forest. To collect one domain:  .\Collect-GpoData.ps1 -Domain corp.example.com
  A GPO that Windows cannot back up is copied from SYSVOL instead and listed in backup-errors.txt.

2. Analyze
  Start GPOCompliance.exe, choose "Open export folder" and pick the GpoExport folder.
  Right-click a domain in the list to mark it as the target or a primary comparison domain.

3. Baselines
  Scores compare the settings that reach each OU with a security baseline. Put extracted baseline packages in a
  folder named "baselines" next to GPOCompliance.exe, or use "Load baseline". Supported: the DISA STIG GPO package
  (listed by NIST in the National Checklist Program) and Microsoft Security Compliance Toolkit baselines.

4. Reports
  "Reports" saves PDF reports: executive summary, baseline compliance, GPO inventory and findings,
  OU and tier review, migration plan.

Notes
  Nothing is sent anywhere. The analyzer makes no network connections and never changes Active Directory.
  Proposed changes (enable or disable a link, new GPOs) exist only in the analyzer's proposal.json file.
  GPOs limited by security filtering or a WMI filter are flagged FILTERED and left out of scores unless
  "Count filtered GPOs" is on.
  Files the analyzer writes into the opened folder: review.json, plan.json, proposal.json.
