# Netring Tech Services, Inc.
# Brian M.

param(
    [string]$OutDir = (Join-Path $PSScriptRoot 'GpoExport'),
    [string[]]$Domain,
    [switch]$SkipBackup
)

$ErrorActionPreference = 'Stop'
Import-Module ActiveDirectory
Import-Module GroupPolicy

if (-not $Domain) { $Domain = (Get-ADForest).Domains }

function Get-ParentDn([string]$dn) { $dn -replace '^(?:\\.|[^,\\])+,', '' }

# When Backup-GPO fails for a GPO, copy its policy files from SYSVOL in the same layout a backup uses.
function Save-GpoFiles($gpo, [string]$domain, [string]$backupDir) {
    try {
        $id  = '{' + $gpo.Id.ToString().ToUpper() + '}'
        $src = "\\$domain\SYSVOL\$domain\Policies\$id"
        if (-not (Test-Path -LiteralPath $src)) { return 'no files in SYSVOL' }
        $dst = Join-Path $backupDir $id
        $gpoDir = Join-Path $dst 'DomainSysvol\GPO'
        New-Item -ItemType Directory -Force -Path $gpoDir | Out-Null
        foreach ($part in 'Machine', 'User') {
            $p = Join-Path $src $part
            if (Test-Path -LiteralPath $p) { Copy-Item -LiteralPath $p -Destination $gpoDir -Recurse -Force -ErrorAction SilentlyContinue }
        }
        $name = [System.Security.SecurityElement]::Escape($gpo.DisplayName)
        "<BackupInst><GPOGuid>$id</GPOGuid><GPODomain>$domain</GPODomain><GPODisplayName>$name</GPODisplayName><BackupTime>$((Get-Date).ToString('s'))</BackupTime></BackupInst>" |
            Set-Content -Path (Join-Path $dst 'bkupInfo.xml') -Encoding UTF8
        return 'policy files copied from SYSVOL instead'
    }
    catch { return "SYSVOL copy also failed: $($_.Exception.Message)" }
}

foreach ($name in $Domain) {
    Write-Host "== $name"
    try {
        $dom = Get-ADDomain -Server $name
        $dc  = $dom.PDCEmulator
        $dir = Join-Path $OutDir $dom.DNSRoot
        New-Item -ItemType Directory -Force -Path $dir | Out-Null

        Write-Host "   counting users"
        $users = @{}
        Get-ADUser -Server $dc -Filter * -ResultPageSize 1000 | ForEach-Object {
            $p = Get-ParentDn $_.DistinguishedName
            $users[$p] = 1 + [int]$users[$p]
        }

        Write-Host "   counting computers"
        $wks = @{}; $srv = @{}; $os = @{}
        Get-ADComputer -Server $dc -Filter * -Properties OperatingSystem -ResultPageSize 1000 | ForEach-Object {
            $p = Get-ParentDn $_.DistinguishedName
            $n = if ($_.OperatingSystem) { [string]$_.OperatingSystem } else { 'Unknown' }
            if (-not $os.ContainsKey($p)) { $os[$p] = @{} }
            $os[$p][$n] = 1 + [int]$os[$p][$n]
            if ($_.OperatingSystem -like '*Server*') { $srv[$p] = 1 + [int]$srv[$p] } else { $wks[$p] = 1 + [int]$wks[$p] }
        }

        Write-Host "   reading OUs and links"
        $props = 'gPLink', 'gPOptions', 'description', 'name'
        $soms  = @(Get-ADObject -Server $dc -Identity $dom.DistinguishedName -Properties $props)
        $soms += @(Get-ADOrganizationalUnit -Server $dc -Filter * -Properties $props)
        # default containers (CN=Users, CN=Computers and the like) hold objects but are not OUs
        $known = @{}; foreach ($o in $soms) { $known[$o.DistinguishedName] = $true }
        $containers = @($users.Keys) + @($wks.Keys) + @($srv.Keys) | Sort-Object -Unique |
            Where-Object { -not $known.ContainsKey($_) -and $_ -like 'CN=*' -and (Get-ParentDn $_) -eq $dom.DistinguishedName }

        $ous = foreach ($o in $soms) {
            $dn = $o.DistinguishedName
            [ordered]@{
                dn           = $dn
                name         = [string]$o.name
                description  = [string]($o.description | Select-Object -First 1)
                gpLink       = [string]$o.gPLink
                gpOptions    = [int]$o.gPOptions
                users        = [int]$users[$dn]
                workstations = [int]$wks[$dn]
                servers      = [int]$srv[$dn]
                os           = if ($os.ContainsKey($dn)) { $os[$dn] } else { @{} }
            }
        }

        $ous = @($ous) + @(foreach ($dn in $containers) {
            [ordered]@{
                dn           = $dn
                name         = ($dn -replace '^CN=((?:\\.|[^,\\])+),.*$', '$1') -replace '\\', ''
                container    = $true
                description  = ''
                gpLink       = ''
                gpOptions    = 0
                users        = [int]$users[$dn]
                workstations = [int]$wks[$dn]
                servers      = [int]$srv[$dn]
                os           = if ($os.ContainsKey($dn)) { $os[$dn] } else { @{} }
            }
        })

        Write-Host "   reading GPOs"
        $gpos = foreach ($g in Get-GPO -All -Domain $dom.DNSRoot -Server $dc) {
            [ordered]@{
                id        = $g.Id.ToString()
                name      = $g.DisplayName
                status    = $g.GpoStatus.ToString()
                wmiFilter = if ($g.WmiFilter) { $g.WmiFilter.Name } else { $null }
            }
        }

        [ordered]@{
            schema       = 1
            domain       = $dom.DNSRoot
            dn           = $dom.DistinguishedName
            collectedUtc = (Get-Date).ToUniversalTime().ToString('o')
            ous          = @($ous)
            gpos         = @($gpos)
        } | ConvertTo-Json -Depth 5 | Set-Content -Path (Join-Path $dir 'domain.json') -Encoding UTF8

        if (-not $SkipBackup) {
            $bdir = Join-Path $dir 'GPOBackups'
            New-Item -ItemType Directory -Force -Path $bdir | Out-Null
            $all = @(Get-GPO -All -Domain $dom.DNSRoot -Server $dc)
            Write-Host "   backing up $($all.Count) GPOs"
            $failed = @()
            foreach ($g in $all) {
                try {
                    Backup-GPO -Guid $g.Id -Domain $dom.DNSRoot -Server $dc -Path $bdir | Out-Null
                }
                catch {
                    $msg = $_.Exception.Message
                    $how = Save-GpoFiles $g $dom.DNSRoot $bdir
                    $failed += "$($g.DisplayName) {$($g.Id)}: $msg ($how)"
                    Write-Warning "   backup failed for '$($g.DisplayName)': $msg ($how)"
                }
            }
            $log = Join-Path $dir 'backup-errors.txt'
            if ($failed.Count -gt 0) {
                $failed | Set-Content -Path $log -Encoding UTF8
                Write-Host "   $($failed.Count) of $($all.Count) GPOs could not be backed up normally, see $log"
            }
            elseif (Test-Path $log) { Remove-Item $log }
        }
        Write-Host "   done: $dir"
    }
    catch {
        Write-Warning "$name failed: $($_.Exception.Message)"
    }
}

Write-Host "Export folder: $OutDir"

# SIG # Begin signature block
# MII9bgYJKoZIhvcNAQcCoII9XzCCPVsCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCSvmHLlxPDS8v6
# S5e8WxY9UhARt3vCyUHfQAGpY9NkhaCCIjAwggXMMIIDtKADAgECAhBUmNLR1FsZ
# lUgTecgRwIeZMA0GCSqGSIb3DQEBDAUAMHcxCzAJBgNVBAYTAlVTMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xSDBGBgNVBAMTP01pY3Jvc29mdCBJZGVu
# dGl0eSBWZXJpZmljYXRpb24gUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAy
# MDAeFw0yMDA0MTYxODM2MTZaFw00NTA0MTYxODQ0NDBaMHcxCzAJBgNVBAYTAlVT
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xSDBGBgNVBAMTP01pY3Jv
# c29mdCBJZGVudGl0eSBWZXJpZmljYXRpb24gUm9vdCBDZXJ0aWZpY2F0ZSBBdXRo
# b3JpdHkgMjAyMDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBALORKgeD
# Bmf9np3gx8C3pOZCBH8Ppttf+9Va10Wg+3cL8IDzpm1aTXlT2KCGhFdFIMeiVPvH
# or+Kx24186IVxC9O40qFlkkN/76Z2BT2vCcH7kKbK/ULkgbk/WkTZaiRcvKYhOuD
# PQ7k13ESSCHLDe32R0m3m/nJxxe2hE//uKya13NnSYXjhr03QNAlhtTetcJtYmrV
# qXi8LW9J+eVsFBT9FMfTZRY33stuvF4pjf1imxUs1gXmuYkyM6Nix9fWUmcIxC70
# ViueC4fM7Ke0pqrrBc0ZV6U6CwQnHJFnni1iLS8evtrAIMsEGcoz+4m+mOJyoHI1
# vnnhnINv5G0Xb5DzPQCGdTiO0OBJmrvb0/gwytVXiGhNctO/bX9x2P29Da6SZEi3
# W295JrXNm5UhhNHvDzI9e1eM80UHTHzgXhgONXaLbZ7LNnSrBfjgc10yVpRnlyUK
# xjU9lJfnwUSLgP3B+PR0GeUw9gb7IVc+BhyLaxWGJ0l7gpPKWeh1R+g/OPTHU3mg
# trTiXFHvvV84wRPmeAyVWi7FQFkozA8kwOy6CXcjmTimthzax7ogttc32H83rwjj
# O3HbbnMbfZlysOSGM1l0tRYAe1BtxoYT2v3EOYI9JACaYNq6lMAFUSw0rFCZE4e7
# swWAsk0wAly4JoNdtGNz764jlU9gKL431VulAgMBAAGjVDBSMA4GA1UdDwEB/wQE
# AwIBhjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTIftJqhSobyhmYBAcnz1AQ
# T2ioojAQBgkrBgEEAYI3FQEEAwIBADANBgkqhkiG9w0BAQwFAAOCAgEAr2rd5hnn
# LZRDGU7L6VCVZKUDkQKL4jaAOxWiUsIWGbZqWl10QzD0m/9gdAmxIR6QFm3FJI9c
# Zohj9E/MffISTEAQiwGf2qnIrvKVG8+dBetJPnSgaFvlVixlHIJ+U9pW2UYXeZJF
# xBA2CFIpF8svpvJ+1Gkkih6PsHMNzBxKq7Kq7aeRYwFkIqgyuH4yKLNncy2RtNwx
# AQv3Rwqm8ddK7VZgxCwIo3tAsLx0J1KH1r6I3TeKiW5niB31yV2g/rarOoDXGpc8
# FzYiQR6sTdWD5jw4vU8w6VSp07YEwzJ2YbuwGMUrGLPAgNW3lbBeUU0i/OxYqujY
# lLSlLu2S3ucYfCFX3VVj979tzR/SpncocMfiWzpbCNJbTsgAlrPhgzavhgplXHT2
# 6ux6anSg8Evu75SjrFDyh+3XOjCDyft9V77l4/hByuVkrrOj7FjshZrM77nq81YY
# uVxzmq/FdxeDWds3GhhyVKVB0rYjdaNDmuV3fJZ5t0GNv+zcgKCf0Xd1WF81E+Al
# GmcLfc4l+gcK5GEh2NQc5QfGNpn0ltDGFf5Ozdeui53bFv0ExpK91IjmqaOqu/dk
# ODtfzAzQNb50GQOmxapMomE2gj4d8yu8l13bS3g7LfU772Aj6PXsCyM2la+YZr9T
# 03u4aUoqlmZpxJTG9F9urJh4iIAGXKKy7aIwggbFMIIEraADAgECAhMzAAx2KRPZ
# /iBolOMkAAAADHYpMA0GCSqGSIb3DQEBDAUAMFoxCzAJBgNVBAYTAlVTMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKzApBgNVBAMTIk1pY3Jvc29mdCBJ
# RCBWZXJpZmllZCBDUyBBT0MgQ0EgMDMwHhcNMjYxMTE3MjE1OTU4WhcNMjYxMTIw
# MjE1OTU4WjCBhTELMAkGA1UEBhMCVVMxFTATBgNVBAgTDFJob2RlIElzbGFuZDET
# MBEGA1UEBxMKR3JlZW52aWxsZTEkMCIGA1UEChMbTmV0cmluZyBUZWNoIFNlcnZp
# Y2VzLCBMTEMuMSQwIgYDVQQDExtOZXRyaW5nIFRlY2ggU2VydmljZXMsIExMQy4w
# ggGiMA0GCSqGSIb3DQEBAQUAA4IBjwAwggGKAoIBgQCPMMjKfoAJzlr7Cdnzg+q9
# OaT0u2WWGxil4Al1y+aKt/kU+jsxF347DLtcCtxer2vVpvoO2brvqrOPEE0p0dGe
# VQMt4mmmujDJHNfCJSRoIPh0BoZ5y2IGPq7uzV1PMC0JmXw/QHx6uz1XRr++O2WQ
# dy2B3jE9imC7CFOt++TpvhyWuuasRdJe5shcDKILA9v82LS+/xmBlkRAEfHGqwjR
# cYElbgONrypSlHhy+OHxdI7o6L+XNge9ZJEUYQCjArVGCKfpVU5+x0KkBQu889BJ
# df29OU6WnyDXNQ0slbYtoX4JzXp8lsdhpSvaM+abLJHK9yJjcx0L9vaFIXfWf2TC
# 4Be6DxnBwNqRGlN0jp/mE0SJ4gCRVUFSSat6j0tU5J6Ap046qgCpiCOnizCb7zM6
# Z3ozPYedjK1E9XKDDMDF+S/Uwmc6dWB0nG1jgROQ5oroyVifY6kCrhUBHmqpWwC2
# ReXSDVbI6q8yUH2CuFZgRWZWEeYDqQElCyZ5LfOKWeECAwEAAaOCAdYwggHSMAwG
# A1UdEwEB/wQCMAAwDgYDVR0PAQH/BAQDAgeAMD0GA1UdJQQ2MDQGCisGAQQBgjdh
# AQAGCCsGAQUFBwMDBhwrBgEEAYI3YYPTtKtig9TFhz+Cl73ReoL+wtlIMB0GA1Ud
# DgQWBBQWQMwisIWnH/rMBcpb+nsouwSnIzAfBgNVHSMEGDAWgBSkQwx/dlqlhec+
# jSgPDBeiRWlwxjBnBgNVHR8EYDBeMFygWqBYhlZodHRwOi8vd3d3Lm1pY3Jvc29m
# dC5jb20vcGtpb3BzL2NybC9NaWNyb3NvZnQlMjBJRCUyMFZlcmlmaWVkJTIwQ1Ml
# MjBBT0MlMjBDQSUyMDAzLmNybDB0BggrBgEFBQcBAQRoMGYwZAYIKwYBBQUHMAKG
# WGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2VydHMvTWljcm9zb2Z0
# JTIwSUQlMjBWZXJpZmllZCUyMENTJTIwQU9DJTIwQ0ElMjAwMy5jcnQwVAYDVR0g
# BE0wSzBJBgRVHSAAMEEwPwYIKwYBBQUHAgEWM2h0dHA6Ly93d3cubWljcm9zb2Z0
# LmNvbS9wa2lvcHMvRG9jcy9SZXBvc2l0b3J5Lmh0bTANBgkqhkiG9w0BAQwFAAOC
# AgEAR4Efeb3DW8z1fRuDadxouR+OZwnOxtY8uE9sxYSXlcOLjEjqGS6oHMl55qXt
# UuNHSaHZQL6SVyvdgs+n0OMfaxZIgqXIYwM6xXH0A33uuPmbtGYyDnu4ALbj/F97
# RVZksR3tvEDZ8sJemR5x9avp//B8z4CiwLJONSa+AGkh2dw9MXU2D5lzYEU6CQQO
# sIq70hc8a0e6DhLQF9LZ7boTDiUFUcMBEY5+wYjkwgJ5CDRWCg9UM/INC+uQzElX
# wl/4BX5MG0HBaCWrZhrmZiTahbrr8R0d65rd23cST7QEKm8SwUzshclYIuZL4Krv
# t13R1BER1yGDb9HXJTwVjpk51oOuDBuHVaRgfcPu+qn5GoJzcs3znVl66WLxEWPU
# w/WOb+0DDUnmRXtS/Humnu42bpKB737JUUF2MPpFNmPpGhWkOhBJBWQcAmEoa8Ty
# dhHFcPYUV0fc9gffxmdd8WIHKyo5fUjnuULP+BgVOhMPeng4YeDM8Yq7BBTORJbC
# JwH5UFSZHefhVxMZ3GYvB7sBl+2/QYaCYmHGmsFPhgu3xnMHllo8tyUK2Sw9qRoZ
# hthNWXmDnnbPts+IA4DCM+6nOfSTAbn3MeZeEuXmsA75sOGBebos6VWTzC67RAlX
# eG5NrpEfl9+LG++ZzjET8MEnU/NSvR0lHqsqXztGsd+QysswggbFMIIEraADAgEC
# AhMzAAx2KRPZ/iBolOMkAAAADHYpMA0GCSqGSIb3DQEBDAUAMFoxCzAJBgNVBAYT
# AlVTMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKzApBgNVBAMTIk1p
# Y3Jvc29mdCBJRCBWZXJpZmllZCBDUyBBT0MgQ0EgMDMwHhcNMjYxMTE3MjE1OTU4
# WhcNMjYxMTIwMjE1OTU4WjCBhTELMAkGA1UEBhMCVVMxFTATBgNVBAgTDFJob2Rl
# IElzbGFuZDETMBEGA1UEBxMKR3JlZW52aWxsZTEkMCIGA1UEChMbTmV0cmluZyBU
# ZWNoIFNlcnZpY2VzLCBMTEMuMSQwIgYDVQQDExtOZXRyaW5nIFRlY2ggU2Vydmlj
# ZXMsIExMQy4wggGiMA0GCSqGSIb3DQEBAQUAA4IBjwAwggGKAoIBgQCPMMjKfoAJ
# zlr7Cdnzg+q9OaT0u2WWGxil4Al1y+aKt/kU+jsxF347DLtcCtxer2vVpvoO2brv
# qrOPEE0p0dGeVQMt4mmmujDJHNfCJSRoIPh0BoZ5y2IGPq7uzV1PMC0JmXw/QHx6
# uz1XRr++O2WQdy2B3jE9imC7CFOt++TpvhyWuuasRdJe5shcDKILA9v82LS+/xmB
# lkRAEfHGqwjRcYElbgONrypSlHhy+OHxdI7o6L+XNge9ZJEUYQCjArVGCKfpVU5+
# x0KkBQu889BJdf29OU6WnyDXNQ0slbYtoX4JzXp8lsdhpSvaM+abLJHK9yJjcx0L
# 9vaFIXfWf2TC4Be6DxnBwNqRGlN0jp/mE0SJ4gCRVUFSSat6j0tU5J6Ap046qgCp
# iCOnizCb7zM6Z3ozPYedjK1E9XKDDMDF+S/Uwmc6dWB0nG1jgROQ5oroyVifY6kC
# rhUBHmqpWwC2ReXSDVbI6q8yUH2CuFZgRWZWEeYDqQElCyZ5LfOKWeECAwEAAaOC
# AdYwggHSMAwGA1UdEwEB/wQCMAAwDgYDVR0PAQH/BAQDAgeAMD0GA1UdJQQ2MDQG
# CisGAQQBgjdhAQAGCCsGAQUFBwMDBhwrBgEEAYI3YYPTtKtig9TFhz+Cl73ReoL+
# wtlIMB0GA1UdDgQWBBQWQMwisIWnH/rMBcpb+nsouwSnIzAfBgNVHSMEGDAWgBSk
# Qwx/dlqlhec+jSgPDBeiRWlwxjBnBgNVHR8EYDBeMFygWqBYhlZodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNyb3NvZnQlMjBJRCUyMFZlcmlm
# aWVkJTIwQ1MlMjBBT0MlMjBDQSUyMDAzLmNybDB0BggrBgEFBQcBAQRoMGYwZAYI
# KwYBBQUHMAKGWGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2VydHMv
# TWljcm9zb2Z0JTIwSUQlMjBWZXJpZmllZCUyMENTJTIwQU9DJTIwQ0ElMjAwMy5j
# cnQwVAYDVR0gBE0wSzBJBgRVHSAAMEEwPwYIKwYBBQUHAgEWM2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvRG9jcy9SZXBvc2l0b3J5Lmh0bTANBgkqhkiG
# 9w0BAQwFAAOCAgEAR4Efeb3DW8z1fRuDadxouR+OZwnOxtY8uE9sxYSXlcOLjEjq
# GS6oHMl55qXtUuNHSaHZQL6SVyvdgs+n0OMfaxZIgqXIYwM6xXH0A33uuPmbtGYy
# Dnu4ALbj/F97RVZksR3tvEDZ8sJemR5x9avp//B8z4CiwLJONSa+AGkh2dw9MXU2
# D5lzYEU6CQQOsIq70hc8a0e6DhLQF9LZ7boTDiUFUcMBEY5+wYjkwgJ5CDRWCg9U
# M/INC+uQzElXwl/4BX5MG0HBaCWrZhrmZiTahbrr8R0d65rd23cST7QEKm8SwUzs
# hclYIuZL4Krvt13R1BER1yGDb9HXJTwVjpk51oOuDBuHVaRgfcPu+qn5GoJzcs3z
# nVl66WLxEWPUw/WOb+0DDUnmRXtS/Humnu42bpKB737JUUF2MPpFNmPpGhWkOhBJ
# BWQcAmEoa8TydhHFcPYUV0fc9gffxmdd8WIHKyo5fUjnuULP+BgVOhMPeng4YeDM
# 8Yq7BBTORJbCJwH5UFSZHefhVxMZ3GYvB7sBl+2/QYaCYmHGmsFPhgu3xnMHllo8
# tyUK2Sw9qRoZhthNWXmDnnbPts+IA4DCM+6nOfSTAbn3MeZeEuXmsA75sOGBebos
# 6VWTzC67RAlXeG5NrpEfl9+LG++ZzjET8MEnU/NSvR0lHqsqXztGsd+Qysswggco
# MIIFEKADAgECAhMzAAAAGA3rkVWpigCYAAAAAAAYMA0GCSqGSIb3DQEBDAUAMGMx
# CzAJBgNVBAYTAlVTMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xNDAy
# BgNVBAMTK01pY3Jvc29mdCBJRCBWZXJpZmllZCBDb2RlIFNpZ25pbmcgUENBIDIw
# MjEwHhcNMjYwMzI2MTgxMTMyWhcNMzEwMzI2MTgxMTMyWjBaMQswCQYDVQQGEwJV
# UzEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSswKQYDVQQDEyJNaWNy
# b3NvZnQgSUQgVmVyaWZpZWQgQ1MgQU9DIENBIDAzMIICIjANBgkqhkiG9w0BAQEF
# AAOCAg8AMIICCgKCAgEAyIDaYDRWoon9lVnlj+SOj5xV8Sf5Qd+3yUeeRgr0exi2
# QTJAYo24ilcIKQSN8TOZ3+POM5x/6p3Cfjgqust44J0FvkfGXe1Puy45a5nLJGpc
# 0kNIITMRKZwVvPxx7NlfGSc0JOhz/kg7G77C+y3ZR/3jtpeJpJ4QwcK9Gf0Peuk7
# xLYeW/JAsY9b6oleGDbYSxkamUfbtnyv8gTFrvN6ejuLqNhHYPvoBHsOSC+7555y
# hapkof0fbzyct1hdWHGXsAFMfLF2TVJ8d2YVYOfZdi6YrT4sMxOhTKiLKmhL1Xtz
# M7hXdmv7lg2R+lWw8lIkSu/JiINQ0GAPcwxMsgRXDSPp8VUs4Jby+ruz0bjaoHFd
# 7H+hC8cPPcrEDP2eEdYURVl0acjliigCrXwR05NFJzYj3MZizDGLPI3lIzonX1T4
# 0yK8v1FcJ8MXZZCvOXGXwRDGGfwwTTsHaJj+OfWNZ/IsypG4bGvqeJcPnEFcQEwR
# cfYIEe/R4a8k+xw5qTy75CbwWeMFuAlt9lE9kjMg3tvJyDlN5voXx5VXinCwUHMp
# uVaEQ4yHAlSO7qoBltjzTBNHH3ovMwsAsuhwrLLCVhUu3oP2GxYZwEyXMlnzK5Db
# gGzHzDfDaYPHK0uo1VaMMg9Bhuc3YIvrkFXEiv+t/JgNcRGCt6ZyKEIDtPbrgwcC
# AwEAAaOCAdwwggHYMA4GA1UdDwEB/wQEAwIBhjAQBgkrBgEEAYI3FQEEAwIBADAd
# BgNVHQ4EFgQUpEMMf3ZapYXnPo0oDwwXokVpcMYwVAYDVR0gBE0wSzBJBgRVHSAA
# MEEwPwYIKwYBBQUHAgEWM2h0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMv
# RG9jcy9SZXBvc2l0b3J5Lmh0bTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTAS
# BgNVHRMBAf8ECDAGAQH/AgEAMB8GA1UdIwQYMBaAFNlBKbAPD2Ns72nX9c0pnqRI
# ajDmMHAGA1UdHwRpMGcwZaBjoGGGX2h0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9w
# a2lvcHMvY3JsL01pY3Jvc29mdCUyMElEJTIwVmVyaWZpZWQlMjBDb2RlJTIwU2ln
# bmluZyUyMFBDQSUyMDIwMjEuY3JsMH0GCCsGAQUFBwEBBHEwbzBtBggrBgEFBQcw
# AoZhaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNyb3Nv
# ZnQlMjBJRCUyMFZlcmlmaWVkJTIwQ29kZSUyMFNpZ25pbmclMjBQQ0ElMjAyMDIx
# LmNydDANBgkqhkiG9w0BAQwFAAOCAgEAcccgVvl+poXUYksA/TzDFnBlAJ8ef0FM
# Jzb2XRRhF/uA0QyK/VgoeAvO8B7cPpYNQ97sytdA7LT19CxSwRQAt71jGF+CJl8K
# C4aEdMZTfJlHaKyd24J6QiVriNed9WdawsD7lK0pAcXziBg5N6dhAm9x6P8R4uT0
# UkfzlK1rkB8F4mlzE7l7tyES3s8FZGaRZjcGEQ+e0fTcdhf8jO7czmNB4dIRgmmB
# Ct/P+ha0tEl2nV1sg1An5+VzhgAkY1Apx8fiUFBtH+Ehw/om5aQCNIJfmR51ZnV1
# 8R02Xk2tAmAiIRcSj9vdtrNIOsy5nolddy1lJrbf1Be061l6TItv9FDZ4mg6B+65
# zxkVecVV/Ll8uLGYouGrMM6jzO2O/ps3K2p6mfBI2ZOYIy4UNwNrGWqa5TrvAmkZ
# sn3CIlR+81X4AL5vNTFlxc4gH+5su0Dr58hBTxnXavDEnz7X0csP1Kt7h+iqaGiT
# SHz2B+n3HmUoud0WrdQPYKxMat0To4YUqU3HIbgSLQDDVT8aCjW1Jvokf1915C/v
# VkIIp48h3voVy3JWPLwBlxQ9aeND6jCKQGLJhCQRSlvXX+P/9TeaEA6/xWPSASZf
# 6Ekve/Yua7U+zWc/Sr2K2gj0QRrNEAsvrFr4EGtHKDO9ECVS3lcJksVDv9KHdMPU
# K8u20i68RqAwggeeMIIFhqADAgECAhMzAAAAB4ejNKN7pY4cAAAAAAAHMA0GCSqG
# SIb3DQEBDAUAMHcxCzAJBgNVBAYTAlVTMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xSDBGBgNVBAMTP01pY3Jvc29mdCBJZGVudGl0eSBWZXJpZmljYXRp
# b24gUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAyMDAeFw0yMTA0MDEyMDA1
# MjBaFw0zNjA0MDEyMDE1MjBaMGMxCzAJBgNVBAYTAlVTMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xNDAyBgNVBAMTK01pY3Jvc29mdCBJRCBWZXJpZmll
# ZCBDb2RlIFNpZ25pbmcgUENBIDIwMjEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAw
# ggIKAoICAQCy8MCvGYgo4t1UekxJbGkIVQm0Uv96SvjB6yUo92cXdylN65Xy96q2
# YpWCiTas7QPTkGnK9QMKDXB2ygS27EAIQZyAd+M8X+dmw6SDtzSZXyGkxP8a8Hi6
# EO9Zcwh5A+wOALNQbNO+iLvpgOnEM7GGB/wm5dYnMEOguua1OFfTUITVMIK8faxk
# P/4fPdEPCXYyy8NJ1fmskNhW5HduNqPZB/NkWbB9xxMqowAeWvPgHtpzyD3PLGVO
# mRO4ka0WcsEZqyg6efk3JiV/TEX39uNVGjgbODZhzspHvKFNU2K5MYfmHh4H1qOb
# U4JKEjKGsqqA6RziybPqhvE74fEp4n1tiY9/ootdU0vPxRp4BGjQFq28nzawuvaC
# qUUF2PWxh+o5/TRCb/cHhcYU8Mr8fTiS15kRmwFFzdVPZ3+JV3s5MulIf3II5FXe
# ghlAH9CvicPhhP+VaSFW3Da/azROdEm5sv+EUwhBrzqtxoYyE2wmuHKws00x4GGI
# x7NTWznOm6x/niqVi7a/mxnnMvQq8EMse0vwX2CfqM7Le/smbRtsEeOtbnJBbtLf
# oAsC3TdAOnBbUkbUfG78VRclsE7YDDBUbgWt75lDk53yi7C3n0WkHFU4EZ83i83a
# bd9nHWCqfnYa9qIHPqjOiuAgSOf4+FRcguEBXlD9mAInS7b6V0UaNwIDAQABo4IC
# NTCCAjEwDgYDVR0PAQH/BAQDAgGGMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQW
# BBTZQSmwDw9jbO9p1/XNKZ6kSGow5jBUBgNVHSAETTBLMEkGBFUdIAAwQTA/Bggr
# BgEFBQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9Eb2NzL1Jl
# cG9zaXRvcnkuaHRtMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMA8GA1UdEwEB
# /wQFMAMBAf8wHwYDVR0jBBgwFoAUyH7SaoUqG8oZmAQHJ89QEE9oqKIwgYQGA1Ud
# HwR9MHsweaB3oHWGc2h0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3Js
# L01pY3Jvc29mdCUyMElkZW50aXR5JTIwVmVyaWZpY2F0aW9uJTIwUm9vdCUyMENl
# cnRpZmljYXRlJTIwQXV0aG9yaXR5JTIwMjAyMC5jcmwwgcMGCCsGAQUFBwEBBIG2
# MIGzMIGBBggrBgEFBQcwAoZ1aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9w
# cy9jZXJ0cy9NaWNyb3NvZnQlMjBJZGVudGl0eSUyMFZlcmlmaWNhdGlvbiUyMFJv
# b3QlMjBDZXJ0aWZpY2F0ZSUyMEF1dGhvcml0eSUyMDIwMjAuY3J0MC0GCCsGAQUF
# BzABhiFodHRwOi8vb25lb2NzcC5taWNyb3NvZnQuY29tL29jc3AwDQYJKoZIhvcN
# AQEMBQADggIBAH8lKp7+1Kvq3WYK21cjTLpebJDjW4ZbOX3HD5ZiG84vjsFXT0OB
# +eb+1TiJ55ns0BHluC6itMI2vnwc5wDW1ywdCq3TAmx0KWy7xulAP179qX6VSBNQ
# kRXzReFyjvF2BGt6FvKFR/imR4CEESMAG8hSkPYso+GjlngM8JPn/ROUrTaeU/BR
# u/1RFESFVgK2wMz7fU4VTd8NXwGZBe/mFPZG6tWwkdmA/jLbp0kNUX7elxu2+HtH
# o0QO5gdiKF+YTYd1BGrmNG8sTURvn09jAhIUJfYNotn7OlThtfQjXqe0qrimgY4V
# poq2MgDW9ESUi1o4pzC1zTgIGtdJ/IvY6nqa80jFOTg5qzAiRNdsUvzVkoYP7bi4
# wLCj+ks2GftUct+fGUxXMdBUv5sdr0qFPLPB0b8vq516slCfRwaktAxK1S40MCvF
# bbAXXpAZnU20FaAoDwqq/jwzwd8Wo2J83r7O3onQbDO9TyDStgaBNlHzMMQgl95n
# HBYMelLEHkUnVVVTUsgC0Huj09duNfMaJ9ogxhPNThgq3i8w3DAGZ61AMeF0C1M+
# mU5eucj1Ijod5O2MMPeJQ3/vKBtqGZg4eTtUHt/BPjN74SsJsyHqAdXVS5c+ItyK
# Wg3Eforhox9k3WgtWTpgV4gkSiS4+A09roSdOI4vrRw+p+fL4WrxSK5nMYIalDCC
# GpACAQEwcTBaMQswCQYDVQQGEwJVUzEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSswKQYDVQQDEyJNaWNyb3NvZnQgSUQgVmVyaWZpZWQgQ1MgQU9DIENB
# IDAzAhMzAAx2KRPZ/iBolOMkAAAADHYpMA0GCWCGSAFlAwQCAQUAoF4wEAYKKwYB
# BAGCNwIBDDECMAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwLwYJKoZIhvcN
# AQkEMSIEIFYRwVm24gCi+eGTB5gX30ECtRxLb1kJqeeVAOcRIKafMA0GCSqGSIb3
# DQEBAQUABIIBgDGzmAA55fM9aP2bLTdmdcxQ0JCVixVwVvAR041ZttGyrGCp0pH3
# gP3PeT8kzAjCoyIU634copwAVWoeE75zBB632omZ0oX47tBQ9RNu0ljFqWLx8lGs
# ghsKIy9xFrb5aD2mmSkCWHp19s233gT6L/pb/TEcrRIiwfk+mv9oYR1uieCjuXLI
# JYSZWzS5MlQ5eB8qgpZd30Mv/1ZqeIPgKOvJ+Op1uOYJaj6z1HjKwe0FgAlvpgUO
# 2fbHpmMNwqxzwBWkMPkG/DpspdOcMqfTozYxjySc502opI4h7yaYeAq1U72+mVpT
# Ej+W9befkOCs3VwelCOocQlQz89NjKzXhw8MTwqNDpJ/dTF2jXgKJ6VRcdjOxbxa
# NvN8twCWXx1NeFET9d9i7JGd/y4vtWgfLqwWXcCAz1DDCIsyGyZS/QiCjqAeGkGw
# OhcG3rrONAMdymwVyQdJT0TAh6/AOoN9rGGkgRVkwjinevPDcE4MIsSdWtS3OM0w
# 13Zm6bH7KmuMqKGCGBQwghgQBgorBgEEAYI3AwMBMYIYADCCF/wGCSqGSIb3DQEH
# AqCCF+0wghfpAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFiBgsqhkiG9w0BCRABBKCC
# AVEEggFNMIIBSQIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFlAwQCAQUABCDWbEsl
# TOQMq5XjN2meoDwD77aEgf7nRnHochfM6L9E8gIGavzfli80GBMyMDI2MTExOTE3
# NTE0My42MzNaMASAAgH0oIHhpIHeMIHbMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRp
# b25zMScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046N0QwMC0wNUUwLUQ5NDcxNTAz
# BgNVBAMTLE1pY3Jvc29mdCBQdWJsaWMgUlNBIFRpbWUgU3RhbXBpbmcgQXV0aG9y
# aXR5oIIPITCCB4IwggVqoAMCAQICEzMAAAAF5c8P/2YuyYcAAAAAAAUwDQYJKoZI
# hvcNAQEMBQAwdzELMAkGA1UEBhMCVVMxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjFIMEYGA1UEAxM/TWljcm9zb2Z0IElkZW50aXR5IFZlcmlmaWNhdGlv
# biBSb290IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDIwMB4XDTIwMTExOTIwMzIz
# MVoXDTM1MTExOTIwNDIzMVowYTELMAkGA1UEBhMCVVMxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFB1YmxpYyBSU0Eg
# VGltZXN0YW1waW5nIENBIDIwMjAwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIK
# AoICAQCefOdSY/3gxZ8FfWO1BiKjHB7X55cz0RMFvWVGR3eRwV1wb3+yq0OXDEqh
# UhxqoNv6iYWKjkMcLhEFxvJAeNcLAyT+XdM5i2CgGPGcb95WJLiw7HzLiBKrxmDj
# 1EQB/mG5eEiRBEp7dDGzxKCnTYocDOcRr9KxqHydajmEkzXHOeRGwU+7qt8Md5l4
# bVZrXAhK+WSk5CihNQsWbzT1nRliVDwunuLkX1hyIWXIArCfrKM3+RHh+Sq5RZ8a
# Yyik2r8HxT+l2hmRllBvE2Wok6IEaAJanHr24qoqFM9WLeBUSudz+qL51HwDYyID
# PSQ3SeHtKog0ZubDk4hELQSxnfVYXdTGncaBnB60QrEuazvcob9n4yR65pUNBCF5
# qeA4QwYnilBkfnmeAjRN3LVuLr0g0FXkqfYdUmj1fFFhH8k8YBozrEaXnsSL3kdT
# D01X+4LfIWOuFzTzuoslBrBILfHNj8RfOxPgjuwNvE6YzauXi4orp4Sm6tF245Da
# FOSYbWFK5ZgG6cUY2/bUq3g3bQAqZt65KcaewEJ3ZyNEobv35Nf6xN6FrA6jF944
# 7+NHvCjeWLCQZ3M8lgeCcnnhTFtyQX3XgCoc6IRXvFOcPVrr3D9RPHCMS6Ckg8wg
# gTrtIVnY8yjbvGOUsAdZbeXUIQAWMs0d3cRDv09SvwVRd61evQIDAQABo4ICGzCC
# AhcwDgYDVR0PAQH/BAQDAgGGMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRr
# aSg6NS9IY0DPe9ivSek+2T3bITBUBgNVHSAETTBLMEkGBFUdIAAwQTA/BggrBgEF
# BQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9Eb2NzL1JlcG9z
# aXRvcnkuaHRtMBMGA1UdJQQMMAoGCCsGAQUFBwMIMBkGCSsGAQQBgjcUAgQMHgoA
# UwB1AGIAQwBBMA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAUyH7SaoUqG8oZ
# mAQHJ89QEE9oqKIwgYQGA1UdHwR9MHsweaB3oHWGc2h0dHA6Ly93d3cubWljcm9z
# b2Z0LmNvbS9wa2lvcHMvY3JsL01pY3Jvc29mdCUyMElkZW50aXR5JTIwVmVyaWZp
# Y2F0aW9uJTIwUm9vdCUyMENlcnRpZmljYXRlJTIwQXV0aG9yaXR5JTIwMjAyMC5j
# cmwwgZQGCCsGAQUFBwEBBIGHMIGEMIGBBggrBgEFBQcwAoZ1aHR0cDovL3d3dy5t
# aWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNyb3NvZnQlMjBJZGVudGl0eSUy
# MFZlcmlmaWNhdGlvbiUyMFJvb3QlMjBDZXJ0aWZpY2F0ZSUyMEF1dGhvcml0eSUy
# MDIwMjAuY3J0MA0GCSqGSIb3DQEBDAUAA4ICAQBfiHbHfm21WhV150x4aPpO4dhE
# mSUVpbixNDmv6TvuIHv1xIs174bNGO/ilWMm+Jx5boAXrJxagRhHQtiFprSjMktT
# liL4sKZyt2i+SXncM23gRezzsoOiBhv14YSd1Klnlkzvgs29XNjT+c8hIfPRe9rv
# VCMPiH7zPZcw5nNjthDQ+zD563I1nUJ6y59TbXWsuyUsqw7wXZoGzZwijWT5oc6G
# vD3HDokJY401uhnj3ubBhbkR83RbfMvmzdp3he2bvIUztSOuFzRqrLfEvsPkVHYn
# vH1wtYyrt5vShiKheGpXa2AWpsod4OJyT4/y0dggWi8g/tgbhmQlZqDUf3UqUQsZ
# aLdIu/XSjgoZqDjamzCPJtOLi2hBwL+KsCh0Nbwc21f5xvPSwym0Ukr4o5sCcMUc
# Sy6TEP7uMV8RX0eH/4JLEpGyae6Ki8JYg5v4fsNGif1OXHJ2IWG+7zyjTDfkmQ1s
# nFOTgyEX8qBpefQbF0fx6URrYiarjmBprwP6ZObwtZXJ23jK3Fg/9uqM3j0P01nz
# VygTppBabzxPAh/hHhhls6kwo3QLJ6No803jUsZcd4JQxiYHHc+Q/wAMcPUnYKv/
# q2O444LO1+n6j01z5mggCSlRwD9faBIySAcA9S8h22hIAcRQqIGEjolCK9F6nK9Z
# yX4lhthsGHumaABdWzCCB5cwggV/oAMCAQICEzMAAABfKuT4I0W8GkkAAAAAAF8w
# DQYJKoZIhvcNAQEMBQAwYTELMAkGA1UEBhMCVVMxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFB1YmxpYyBSU0EgVGlt
# ZXN0YW1waW5nIENBIDIwMjAwHhcNMjYwOTE3MTg1NzI1WhcNMjcwOTE0MTg1NzI1
# WjCB2zELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjElMCMGA1UE
# CxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9uczEnMCUGA1UECxMeblNoaWVs
# ZCBUU1MgRVNOOjdEMDAtMDVFMC1EOTQ3MTUwMwYDVQQDEyxNaWNyb3NvZnQgUHVi
# bGljIFJTQSBUaW1lIFN0YW1waW5nIEF1dGhvcml0eTCCAiIwDQYJKoZIhvcNAQEB
# BQADggIPADCCAgoCggIBAOdUl8NedLs3VQ2koPcvNTdChdfvpgMFqTaUUIBfKxHP
# TVorMISrSoEXq4fj410h24sCKpWb1+LulcEQ3TZjaNqAUX4nhMRq0zcOepGiwgd9
# cFb8gTLeS8YuIZCHNtRJPqaAM1PRIUYLFK+zGCUCynAS9Oxhl9/zxnUqyzU5IMWl
# M/9qGb3JkuH/KqqFQTlIdtomu0BSRz1DmtdpqMRps3tvBbvficbaPJCxGfRrPStg
# k2Ky8bOikj9dFsI6LgI9n0oKh9jzqG93rooMy8KZo+mIfinSbtDWATX6BAUyS1e5
# D8eR6GV5En/2M94fRvV0DRXDYm06raZEfD6XY2DHUSb56BFWv/L633ObG7mKyZFX
# mfR9eh1VBg7Ax1j7y59TEsTE4OE3dyb+mObZwJ5f8h8YkBZRNc1v3Nnyn2Lw/mXE
# nihGL1E5qd9f22dFfKZhDg/SC94BAm+2unBobDGb6c4OllDaVuugsC/5uTFyxM6z
# NKiTZ2FBdUZGkPCGLhmM3ST39OotArv3XhLImS24ZAnGRt1lY/ybgY2EIipfDisK
# rP/0GsJ+znMsVNXFi9yd+8ej7Wugsiq8Wdq64hQTICAyRySAyeJMD4p75ZFA28C5
# 46NIbNEpovdN3pg3RvSB/71xsz0ohSL3ofubIN3ol2G5JZHx2GTjOZkT+bBOhl1d
# AgMBAAGjggHLMIIBxzAdBgNVHQ4EFgQUUodPDdEuenjFeaL29gqA7/w5WtwwHwYD
# VR0jBBgwFoAUa2koOjUvSGNAz3vYr0npPtk92yEwbAYDVR0fBGUwYzBhoF+gXYZb
# aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jcmwvTWljcm9zb2Z0JTIw
# UHVibGljJTIwUlNBJTIwVGltZXN0YW1waW5nJTIwQ0ElMjAyMDIwLmNybDB5Bggr
# BgEFBQcBAQRtMGswaQYIKwYBBQUHMAKGXWh0dHA6Ly93d3cubWljcm9zb2Z0LmNv
# bS9wa2lvcHMvY2VydHMvTWljcm9zb2Z0JTIwUHVibGljJTIwUlNBJTIwVGltZXN0
# YW1waW5nJTIwQ0ElMjAyMDIwLmNydDAMBgNVHRMBAf8EAjAAMBYGA1UdJQEB/wQM
# MAoGCCsGAQUFBwMIMA4GA1UdDwEB/wQEAwIHgDBmBgNVHSAEXzBdMFEGDCsGAQQB
# gjdMg30BATBBMD8GCCsGAQUFBwIBFjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20v
# cGtpb3BzL0RvY3MvUmVwb3NpdG9yeS5odG0wCAYGZ4EMAQQCMA0GCSqGSIb3DQEB
# DAUAA4ICAQAxolcM7ro14Qopp30xaTVEKAUJBtANX1pePyuKKhQoevySvsWXQONh
# jRqCGeUG8ZbOHDEwx3xAh6/gOWcyGfQGTg7x5D670wG7St8HWspA721iwviz9Ema
# dx6Xmql9/fjEqI7JZvgKKqasEAdMWswa2f3ktgIWqCjV3dHKC4SfRJ8M4TtPwuxY
# Bhvri1kuagUO++ur6YLhI237TYr1OaHaPWF5T7j25oR0ScAXIWUhWyzVf/SXXHup
# w83RudfaO7DicMwCEiw05YVzdnsx+DakSKRWKPTtqr4zV3zQ6KKah6HoNAaAz2nH
# aLoiU62eBdhcmEtZcEFq2NQkt+ts7pIRVnpQYjpPBwsX8lyz55KyiiHcSHoBFR8/
# 9iM3IcUFXPY5NnfplGXVD0hsmmGQQBmGGP13Vef+xurwt1qGeHbnE6Aks4SOJN6f
# E5X57IDGkrkNvzK8rm1+8Oo7z8dPjV4WLkvUTnMtkoLfOOqvswM4VjNmhWqcJn/2
# hr1CLT44hHHTZBH8E4Ri4ZTtqfjRQwPHlgF+vVQjYoBgFIXsvTxSZG2LLWyxMRky
# xCQdpplj6ZUnUDY4ij9cxOZPZcVsnaj/VLML72DHHvUJoS9XWaFMnu2NAbg81JwG
# j6CiY3tyQ/btHWA01Hcaouw9BWWyOENI5eAuS/VLRsHyqi4THRXDIzGCB0YwggdC
# AgEBMHgwYTELMAkGA1UEBhMCVVMxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFB1YmxpYyBSU0EgVGltZXN0YW1waW5n
# IENBIDIwMjACEzMAAABfKuT4I0W8GkkAAAAAAF8wDQYJYIZIAWUDBAIBBQCgggSf
# MBEGCyqGSIb3DQEJEAIPMQIFADAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQAQQw
# HAYJKoZIhvcNAQkFMQ8XDTI2MTExOTE3NTE0M1owLwYJKoZIhvcNAQkEMSIEILxK
# cjlH+P6kybVCuB21KaHL2XGDLFjfSTGtWtQv3eLUMIG5BgsqhkiG9w0BCRACLzGB
# qTCBpjCBozCBoAQgbPYJfqtX9IDg0oUk9Eqwt1BebJx51uJ/MF5Sx1suJcMwfDBl
# pGMwYTELMAkGA1UEBhMCVVMxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFB1YmxpYyBSU0EgVGltZXN0YW1waW5nIENB
# IDIwMjACEzMAAABfKuT4I0W8GkkAAAAAAF8wggNhBgsqhkiG9w0BCRACEjGCA1Aw
# ggNMoYIDSDCCA0QwggIsAgEBMIIBCaGB4aSB3jCB2zELMAkGA1UEBhMCVVMxEzAR
# BgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1p
# Y3Jvc29mdCBDb3Jwb3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2Eg
# T3BlcmF0aW9uczEnMCUGA1UECxMeblNoaWVsZCBUU1MgRVNOOjdEMDAtMDVFMC1E
# OTQ3MTUwMwYDVQQDEyxNaWNyb3NvZnQgUHVibGljIFJTQSBUaW1lIFN0YW1waW5n
# IEF1dGhvcml0eaIjCgEBMAcGBSsOAwIaAxUAcQk63vC8u5jLrwCI8lNL7oby7G+g
# ZzBlpGMwYTELMAkGA1UEBhMCVVMxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFB1YmxpYyBSU0EgVGltZXN0YW1waW5n
# IENBIDIwMjAwDQYJKoZIhvcNAQELBQACBQDuqVhUMCIYDzIwMjYxMTE5MTExMzI0
# WhgPMjAyNjExMjAxMTEzMjRaMHcwPQYKKwYBBAGEWQoEATEvMC0wCgIFAO6pWFQC
# AQAwCgIBAAICJX0CAf8wBwIBAAICGk8wCgIFAO6qqdQCAQAwNgYKKwYBBAGEWQoE
# AjEoMCYwDAYKKwYBBAGEWQoDAqAKMAgCAQACAwehIKEKMAgCAQACAwGGoDANBgkq
# hkiG9w0BAQsFAAOCAQEAHWuxeXM9pSefS6jIlLqqhpUCa2kj1Tj6n/D5KrC052Xn
# s2lLJVOxTKEdbQ2gQgwqq9cUIKtGyOR5aTZWJ8GGchVXqflKMzsnNEbVnQuekqYO
# fHMPzLnWnmsuFOWgt7/rTD2W4jzEeNIxd8Gh4ItAPAWgeKqJlxSE7XioeUAYWddu
# b5QxDdNx4NuZrmDr/O6S5cRVm+syzhWJKoeMWEzslcCpfPiXL9G+CtZv1tU/eqnH
# BXFemomciqEK31lqehw9KF3RhCAFT+1ZIrvfAkTlQ5gJqRL/LUQLGfkepYSh7szH
# miv0qCIhRKQ4I//jtNU2o7d3yPBF16UhtMAl5eQKFTANBgkqhkiG9w0BAQEFAASC
# AgC5Gc4iqBXiOkFmaiO728ayN/8n6SDR8OqbGh84jvt9CIu2e8gXwwUDHu/BOjbA
# AI5oK43oeG/435qyfRGAvgD6hCE6DugPSxdb/1b97Niqxkpb0L1ie+E6blFdO1J0
# I0VFqjF8VPSr6aH1qneuQEXKPIXWGeiabYhwofy+F91JEhI9GpX0Afw2VTUKcSST
# F+BZTh/6vBoC9H/PYy52OVhJ8zwUC88nt7B95DWifbaNGNhKvfeBRKr8/vGvjSvP
# A4WqSz49fBdJ592mqzXSfoEbEXW4h1VkhF6/ZzDV7IPeB0tOuKpd447WyvIzgC9O
# labxInb6wYNXWKG/S4iwKyA+QtuTfU+hfDIc+6yqHt27SbFOZNImN/nRb4tefuxu
# IzBWPG2RfzEYjWX87r+xlpLeKOktFROjrp7AQTwf1aQ5rb9d7zoNOCKW2zxTc9y3
# SdpV16TX82BfpwIOr+cEHa+1zVBME6t1RldJfWGuq3SeIvYTmIWlw9+uUeP4DhfI
# XiL0owU6JrsjOARhVlSbDV0s0EhUs3i0Ka8rvHkoHLs1Os3zxbjf9/0TqRwUWr/u
# K2tFdEGGArMPJKP1u+UfdbI2qBD8/lDbqwJMgrl2xkqpv6DKI9Gg6jlOqqQVZ09+
# Wt42AsYmuQ50+HghPimXxFqLlTCJ5/fErarM7Aaru4viPw==
# SIG # End signature block
